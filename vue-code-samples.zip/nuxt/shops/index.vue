<template>
  <div>
    <simple-header />
    <article class="container-fluid all-shops pl-0 pr-0" id="all-shops">
      <div class="row line padding">
        <div class="col-12 col-lg-4 pl-0 pr-0 mr-auto">
          <h2 class="shops-title">{{$t('All shops')}}</h2>
        </div>
        <div class="col-12 col-lg-8 pl-0 pr-0 shops-buttons">
          <no-ssr>
            <b-dropdown
              class="country"
              id="countries"
              toggle-class="country-button"
              menu-class
              variant="none"
            >
              <template slot="button-content">
                <arrow-right path-class />
                <span
                  class="country-button-text"
                >{{(chosenCountry ? $t('countries-abbr.' + chosenCountry) : $t('All countries')) | capitalize}}</span>
              </template>
              <b-dd-item @click.prevent="chosenCountry = ''">{{$t('All countries')}}</b-dd-item>
              <b-dd-item
                @click.prevent="chosenCountry = code"
                v-for="(name, code) in $t('countries-abbr')"
                :key="code"
              >{{name}}</b-dd-item>
            </b-dropdown>
          </no-ssr>
          <b-dropdown
            class="sneakers"
            id="brands"
            toggle-class="sneakers-button"
            menu-class
            variant="none"
          >
            <template slot="button-content">
              <arrow-right path-class />
              <span
                class="sneakers-button-text"
              >{{(chosenBrand ? chosenBrand : $t('All Brands')) | titleCase}}</span>
            </template>
            <b-dd-item @click.prevent="chosenBrand = ''">{{$t('All brands')}}</b-dd-item>
            <b-dd-item
              v-for="brand in brands"
              @click.prevent="chosenBrand = brand"
              :key="brand"
            >{{brand | titleCase}}</b-dd-item>
          </b-dropdown>
          <div class="switcher">
            <div class="onoffswitch">
              <input
                v-model="onlineOnly"
                type="checkbox"
                name="onoffswitch"
                class="onoffswitch-checkbox"
                id="myonoffswitch"
              />
              <label class="onoffswitch-label" for="myonoffswitch">
                <span class="onoffswitch-inner"></span>
                <span class="onoffswitch-switch"></span>
              </label>
            </div>
            <p class="switcher-text">{{$t('Online only')}}</p>
          </div>
        </div>
      </div>
      <div class="row line shopcards">
        <template v-for="shop in loadedShops.data">
          <shop-thumbnail :shop="shop" :key="shop.id"></shop-thumbnail>
        </template>
      </div>
      <div class="row line button-row">
        <button class="button-main" @click="loadMore" v-if="loadedShops.next_page_url">
          <arrow-right path-class />
          <span class="button-main-text">{{$t('labels.loadmore', {item : 'Shops' })}}</span>
        </button>
      </div>
      <div
        class="seo-description my-5 py-5 col-12"
        v-show="currentRouteMetas.seo_description[currentLang] && !loadedShops.next_page_url"
      >
        <div class="row line">
          <link-parser :add-locale="currentLang" :content="seoHTML" />
        </div>
      </div>
    </article>
  </div>
</template>

<script>
import { mapState, mapActions } from "vuex";
import ShopThumbnail from "../../../components/ShopThumbnail";
import SimpleHeader from "../../../components/SimpleHeader";
import ArrowRight from "../../../components/icons/arrow-right";
import staticMetasMixin from "../../../plugins/staticMetasMixin";
import LinkParser from "../../../components/linkParser";

export default {
  name: "shops",
  components: { LinkParser, ArrowRight, SimpleHeader, ShopThumbnail },
  mixins: [staticMetasMixin],
  middleware: "loadMeta",
  fetch({ store }) {
    if (!store.state.loadedShops.data) {
      return store.dispatch("loadShops");
    }
  },
  asyncData({ store }) {
    return {
      chosenCountry: store.state.shopsQueries.country,
      chosenBrand: store.state.shopsQueries.brand,
      onlineOnly: store.state.shopsQueries.online_only,
    };
  },
  computed: {
    ...mapState([
      "brands",
      "loadedShops",
      "currentRouteMetas",
      "currentLang",
      "totalSneakersCount",
      "totalShopsCount",
    ]),
    seoHTML() {
      return this.currentRouteMetas.seo_description[this.currentLang]
        ? this.currentRouteMetas.seo_description[this.currentLang]
            .replace(/%{total}/g, this.totalSneakersCount)
            .replace(/%{shopsCount}/g, this.totalShopsCount)
        : "";
    },
    schemaBreadcrumbs() {
      return {
        script: [
          {
            hid: "breadcrumbs",
            type: "application/ld+json",
            innerHTML: JSON.stringify(
              {
                "@context": "http://schema.org",
                "@type": "BreadcrumbList",
                itemListElement: [
                  {
                    "@type": "ListItem",
                    position: 1,
                    item: {
                      "@id": "sneakers123.com/" + this.currentLang,
                      name: this.$t("Sneaker Search Engine"),
                    },
                  },
                  {
                    "@type": "ListItem",
                    position: 2,
                    item: {
                      "@id": "https://sneakers123.com" + this.$route.path,
                      name: this.$t("Shops"),
                    },
                  },
                ],
              },
              null,
              2
            ),
          },
        ],
      };
    },
  },
  watch: {
    async chosenCountry(val) {
      this.$nuxt.$loading.start();
      await this.changeShopsQuery({
        field: "country",
        data: val,
      });
      this.$nuxt.$loading.finish();
    },
    async chosenBrand(val) {
      this.$nuxt.$loading.start();
      await this.changeShopsQuery({
        field: "brand",
        data: val,
      });
      this.$nuxt.$loading.finish();
    },
    async onlineOnly(val) {
      this.$nuxt.$loading.start();
      await this.changeShopsQuery({
        field: "online_only",
        data: val,
      });
      this.$nuxt.$loading.finish();
    },
  },
  methods: {
    ...mapActions(["changeShopsQuery"]),
    async loadMore() {
      this.$nuxt.$loading.start();
      await this.changeShopsQuery({
        field: "page",
        data: this.loadedShops.current_page + 1,
      });
      this.$nuxt.$loading.finish();
    },
  },
};
</script>

<style scoped>
</style>
