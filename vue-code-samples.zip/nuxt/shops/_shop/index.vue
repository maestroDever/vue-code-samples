<template>
  <div>
    <simple-header />
    <article class="shopinfo" id="shopinfo" v-if="!_.isEmpty(shop)">
      <div class="top">
        <div class="left-top">
          <div class="wraper wraper-top">
            <h1 class="name">{{shop.name}}</h1>
            <no-ssr>
              <div class="d-flex flex-wrap align-items-center rating-container">
                <span class="rating-value">{{ shop.rating }}</span>
                <star-rating
                  class="d-inline-flex"
                  @rating-selected="setRating"
                  v-bind:read-only="!canUserRate(shop.id)"
                  v-bind:round-start-rating="false"
                  v-bind:star-size="30"
                  v-bind:show-rating="false"
                  v-model="rating"
                ></star-rating>
                <span class="align-self-end rating-text">
                  <span v-if="shop.rating != 0">({{ shop.reviewsCount }} {{ $t('shop-rating')}})</span>
                  <span v-else>{{ $t('evaluate-first')}}</span>
                </span>
                <span class="mt-2 color-blue w-100" v-if="ratingInfo">{{ ratingInfo }}</span>
              </div>
            </no-ssr>
            <h2 class="description" v-html="description"></h2>
            <arrow-right path-class />
          </div>
        </div>
        <div class="right-top" v-if="hasImage">
          <div class="swiper-container">
            <div class="swiper-wrapper">
              <template v-for="(image, index) in shop.images">
                <div class="swiper-slide" :key="index">
                  <img class="slide-img" :src="image" :alt="shop.name + ' photo ' + index" />
                </div>
              </template>
            </div>
            <div class="swiper-pagination"></div>
          </div>
        </div>
      </div>
      <div class="bottom">
        <div class="left-bottom">
          <div class="wraper">
            <h3 class="country">{{$t('countries-abbr.' + shop.country)}}</h3>
            <span v-html="shop.address"></span>
          </div>
        </div>
        <div class="right-bottom"></div>
      </div>
    </article>

    <section class="brands-container" v-if="!_.isEmpty(shop.brands)">
      <div class="row line">
        <h2 class="col-12 primary-title mb-3">{{ $t('our-brands') }}</h2>
      </div>
      <div class="row line justify-content-center">
        <template v-for="(brand) in shop.brands">
          <div class="brand-logo-wrap">
            <img class="brand-logo-img" :src="svg(brand)" :alt="brand" />
          </div>
        </template>
      </div>
    </section>

    <article
      class="shop-coupons container-fluid pl-0 pr-0"
      id="shop-coupons"
      v-if="!_.isEmpty(shop.vouchers)"
    >
      <div class="row line">
        <h2 class="shop-coupons-title col-12">{{$t('Coupon codes')}}</h2>
      </div>
      <div class="swiper-container2">
        <div class="swiper-wrapper row line flex-nowrap">
          <template v-for="voucher in shop.vouchers">
            <voucher-thumbnail :voucher="voucher" :slide="true" :key="voucher.id"></voucher-thumbnail>
          </template>
        </div>
        <div class="swiper-pagination2"></div>
      </div>
    </article>

    <article
      class="container-fluid shop-products"
      id="shop-products"
      v-if="!_.isEmpty(shop.sneakers)"
    >
      <div class="row line">
        <h2 class="col-12 shop-products-title">{{$t('Products in our shop')}}</h2>
      </div>
      <div class="row line">
        <no-ssr>
          <template v-for="sneaker in shop.sneakers">
            <sneaker-thumbnail :sneaker="sneaker" :key="sneaker.id"></sneaker-thumbnail>
          </template>
        </no-ssr>
      </div>
      <div class="row line shop-products-footer">
        <nuxt-link class="button-main" :to="redirectUrl" target="_blank" rel="nofollow">
          <arrow-right path-class />
          <span class="button-main-text">{{$t('go-to-shop', {shop: shop.name})}}</span>
        </nuxt-link>
      </div>
    </article>
  </div>
</template>

<script>
import Swiper from "swiper";
import SneakerThumbnail from "../../../../components/Sneakers/Thumbnail";
import VoucherThumbnail from "../../../../components/Sneakers/VoucherThumbnail";
import StarRating from "vue-star-rating";
import { mapMutations, mapState } from "vuex";
import SimpleHeader from "../../../../components/SimpleHeader";
import staticMetasMixin from "../../../../plugins/staticMetasMixin";
import ArrowRight from "../../../../components/icons/arrow-right";

export default {
  name: "Shop",
  components: {
    ArrowRight,
    SimpleHeader,
    SneakerThumbnail,
    VoucherThumbnail,
    StarRating,
  },
  props: ["data"],
  mixins: [staticMetasMixin],
  middleware: "loadMeta",
  data: () => {
    return {
      rating: 0,
      ratingInfo: "",
    };
  },
  async asyncData({ store, params, $axios }) {
    try {
      let { data } = await $axios.get("shops/" + params.shop);
      return { shop: data };
    } catch (e) {
      console.log("shop ", e.response ? e.response.status : e);
    }
  },
  methods: {
    ...mapMutations(["updateUserInfo"]),

    setRating(rating) {
      if (!this._.isEmpty(this.user)) {
        try {
          this.$axios
            .post(`shops/rate`, {
              shop_id: this.shop.id,
              user_id: this.user.id,
              rating: rating,
            })
            .then((response) => {
              this.rating = +response.data.newRating;
              this.shop.rating = response.data.newRating;
              this.shop.reviewsCount += 1;
              this.updateUserInfo(response.data.user);
            });
        } catch (e) {
          console.log("shop rate", e.response ? e.response.status : e);
        }
      }
    },
    canUserRate(shopId) {
      /* user can rate only if he logged in & made a purchase in a specific shop & hadn't rate yet*/
      if (this._.isEmpty(this.user)) {
        /*  user is not signed in */
        this.ratingInfo = this.$t("only-registered-users-can-rate");
        return false;
      }
      //TODO: add if user has made a purchase
      // if(this.user.available_shops_for_rating.contains(shopId))
      //     return true;

      let shopsRatings = this.user.shop_ratings;
      for (let index in shopsRatings) {
        if (shopsRatings[index].shop_id === shopId) {
          /*  user already rated this shop */
          this.ratingInfo = this.$t("already-rated-text");
          return false;
        }
      }
      this.ratingInfo = "";
      return true;
    },
  },
  computed: {
    ...mapState(["currentRouteMetas", "currentLang", "user"]),

    hasImage() {
      return !this._.isEmpty(this.shop.images);
    },
    description() {
      return this._.isEmpty(
        this.shop.description[this.$route.params.locale.toUpperCase()]
      )
        ? this.shop.description[this.$route.params.locale]
        : "";
    },
    redirectUrl() {
      let query = {
        to: this.linkToShop,
        partner: this.shop.name,
        type: "shop",
      };
      return { name: "locale-go", params: { locale: this.currentLang }, query };
    },
    linkToShop() {
      if (!this._.isEmpty(this.shop.affiliate_link)) {
        if (this._.startsWith(this.shop.affiliate_link, "?")) {
          return this.shop.website + this.shop.affiliate_link;
        }
        return this.shop.affiliate_link + encodeURI(this.shop.website);
      }
      return this.shop.website;
    },
    schemaBreadcrumbs() {
      return {
        script: [
          {
            hid: "breadcrumbs",
            type: "application/ld+json",
            innerHTML: JSON.stringify(
              {
                "@context": "http://schema.org",
                "@type": "BreadcrumbList",
                itemListElement: [
                  {
                    "@type": "ListItem",
                    position: 1,
                    item: {
                      "@id": "sneakers123.com/" + this.currentLang,
                      name: this.$t("Sneaker Search Engine"),
                    },
                  },
                  {
                    "@type": "ListItem",
                    position: 2,
                    item: {
                      "@id": "sneakers123.com/" + this.currentLang + "/shops",
                      name: this.$t("Shops"),
                    },
                  },
                  {
                    "@type": "ListItem",
                    position: 3,
                    item: {
                      "@id": "https://sneakers123.com" + this.$route.path,
                      name: this.$t("Shops") + " " + this.shop.name,
                    },
                  },
                ],
              },
              null,
              2
            ),
          },
        ],
      };
    },
  },
  mounted() {
    this.rating = +this.shop.rating;

    let swiper = new Swiper(".swiper-container", {
      spaceBetween: 0,
      centeredSlides: true,
      autoplay: {
        delay: 3500,
        disableOnInteraction: false,
      },
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
      },
    });
    let swiper2 = new Swiper(".swiper-container2", {
      slidesPerView: 2,
      pagination: {
        el: ".swiper-pagination2",
        clickable: true,
      },
      breakpoints: {
        576: {
          slidesPerView: 1,
        },
      },
    });
  },
};
</script>

<style scoped>
h3,
h4 {
  font-weight: inherit;
}
</style>
