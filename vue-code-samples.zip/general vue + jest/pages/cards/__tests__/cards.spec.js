import Cards from '../cards';

describe('Cards component', () => {
  describe('methods', () => {
    describe('closeAddPaymentCardModal', () => {
      it('should set addPaymentCardModalOpened flag to false', () => {
        const context = {
          addPaymentCardModalOpened: true,
        };

        Cards.methods.closeAddPaymentCardModal.call(context);
        expect(context.addPaymentCardModalOpened).toBe(false);
      });
    });
  });
});
