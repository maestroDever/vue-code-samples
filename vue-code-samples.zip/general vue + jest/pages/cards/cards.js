import userIsSubscribed from '../../mixins/user-is-subscribed';
import AddPaymentCard from '../../modals/add-payment-card';
import CardItem from '../../components/card-item';
import { createNamespacedHelpers } from 'vuex';
import stripeDestroyComponentHook from '../../utils/stripe-destroy-component-hook';

const { mapGetters } = createNamespacedHelpers('cards');

export default {
  name: 'Cards',
  mixins: [userIsSubscribed],
  components: {
    AddPaymentCard,
    CardItem,
  },
  data() {
    return {
      addPaymentCardModalOpened: false,
    };
  },
  computed: {
    ...mapGetters(['paymentCards']),
    stripeCustomerToken() {
      return this.$store.state.user.stripeCustomerToken;
    },
  },
  methods: {
    closeAddPaymentCardModal() {
      this.addPaymentCardModalOpened = false;
    },
  },
  beforeRouteLeave: stripeDestroyComponentHook,
};
