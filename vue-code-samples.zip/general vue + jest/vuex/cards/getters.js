export const stripeUserData = state => state;

export const paymentCards = state => state.paymentCards;

export const stripeCustomerToken = state => state.stripeCustomerToken;

export const defaultCardId = state => state.defaultCardId;
