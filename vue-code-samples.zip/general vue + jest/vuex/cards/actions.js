import Parse from '../parse';
import { createToken } from 'vue-stripe-elements-plus';
import { createWorkerStripeCustomerToken } from '../workers/utils/queries';

export const init = async ({ commit, rootState }) => {
  const { stripeCustomerToken, id } = rootState.user;
  let paymentCards = [];
  let defaultCardId = '';

  if (!stripeCustomerToken) {
    await createWorkerStripeCustomerToken(id, rootState).then((response) => {
      const { customerToken } = response;
      commit('user/SET_STRIPE_CUSTOMER_TOKEN', customerToken);
    });
  }
  if (stripeCustomerToken) {
    const stripeData = await Parse.Cloud.run('stripe_getCustomer', {
      token: stripeCustomerToken,
    });

    paymentCards = stripeData.sources.data;
    defaultCardId = stripeData.default_source;
  }

  commit('INIT', { paymentCards, defaultCardId });
};

export const addPaymentCard = async ({ commit, rootState }) => {
  const { stripeCustomerToken } = rootState.user;
  const { token } = await createToken(stripeCustomerToken);

  await Parse.Cloud.run('stripe_saveCardToCustomer', {
    customerToken: stripeCustomerToken,
    cardToken: token.id,
  });

  commit('ADD_CARD', token.card);

  return token.card;
};

export const removePaymentCard = async ({ commit, rootState }, cardId) => {
  const { stripeCustomerToken } = rootState.user;

  await Parse.Cloud.run('stripe_deleteCard', {
    customerToken: stripeCustomerToken,
    cardToken: cardId,
  });

  // fix i18n error
  setTimeout(() => {
    commit('DELETE_CARD', cardId);
  }, 0);
};

export const setDefault = async ({ commit, rootState }, cardId) => {
  const { stripeCustomerToken } = rootState.user;

  await Parse.Cloud.run('stripe_setDefaultCard', {
    customerToken: stripeCustomerToken,
    cardToken: cardId,
  });

  commit('SORT_CARDS_BY_DEFAULT', cardId);
  commit('SET_DEFAULT_CARD_ID', cardId);
};
