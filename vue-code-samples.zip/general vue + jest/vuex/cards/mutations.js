import initialState from './initial-state';

export const INIT = (state, cardsData) => {
  state = Object.assign(state, cardsData);
};

// eslint-disable-next-line no-unused-vars
export const RESET = (state) => {
  state = Object.assign(state, initialState);
};

export const ADD_CARD = (state, cardData) => {
  state.paymentCards = [...state.paymentCards, cardData];
};

export const DELETE_CARD = (state, id) => {
  state.paymentCards = state.paymentCards.filter(card => card.id !== id);
};

export const SORT_CARDS_BY_DEFAULT = (state, id) => {
  state.paymentCards = state.paymentCards.reduce((acc, card) => {
    if (card.id === id) {
      return [card].concat(acc);
    }

    return acc.concat(card);
  }, []);
};

export const SET_DEFAULT_CARD_ID = (state, id) => {
  state.defaultCardId = id;
};
