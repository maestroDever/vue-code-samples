import initialState from './initial-state';

export default { ...initialState };
