export default {
  paymentCards: [],
  error: '',
  defaultCardId: '',
  stripeCustomerToken: '',
};
