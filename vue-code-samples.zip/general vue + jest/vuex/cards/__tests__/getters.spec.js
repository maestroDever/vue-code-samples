import * as getters from '../getters';

describe('Vuex', () => {
  describe('cards module', () => {
    describe('getters', () => {
      const testState = {
        paymentCards: [
          { id: 'card id 1' },
          { id: 'card id 2' },
        ],
        error: 'some error',
        defaultCardId: 'default card id',
        stripeCustomerToken: 'stripe customer token',
      };

      describe('stripeUserDate', () => {
        it('should return state', () => {
          expect(getters.stripeUserData(testState)).toEqual(testState);
        });
      });

      describe('paymentCards', () => {
        it('should return array of payment cards', () => {
          const { paymentCards: expected } = testState;
          expect(getters.paymentCards(testState)).toEqual(expected);
        });
      });

      describe('stripeCustomerToken', () => {
        it('should return stripe customer token', () => {
          const { stripeCustomerToken: expected } = testState;
          expect(getters.stripeCustomerToken(testState)).toEqual(expected);
        });
      });

      describe('defaultCardId', () => {
        it('should return default card id', () => {
          const { defaultCardId: expected } = testState;
          expect(getters.defaultCardId(testState)).toEqual(expected);
        });
      });
    });
  });
});
