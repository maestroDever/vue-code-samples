import * as actions from '../actions';
import Parse from 'parse';
import { createToken } from 'vue-stripe-elements-plus';

jest.mock('parse');
jest.mock('vue-stripe-elements-plus', () =>
  ({
    createToken: jest.fn(),
  }));

describe('Vuex', () => {
  describe('cards module', () => {
    describe('actions', () => {
      describe('init', () => {
        it('should commit INIT mutation if Parse request has been successful', async () => {
          const commit = jest.fn();
          const rootState = {
            user: {
              stripeCustomerToken: 'some fancy token',
            },
          };
          const expectedMutation = 'INIT';
          const payload = {
            stripeCustomerToken: 'test',
            notifyFail: jest.fn(),
            triggerLoader: jest.fn(),
          };
          const paymentCards = [
            {
              brand: 'test',
            },
          ];

          const defaultCardId = 'default_card_id';

          const expectedCards = {
            sources: {
              data: paymentCards,
            },
            default_source: defaultCardId,
          };

          Parse.Cloud.run.mockResolvedValue(expectedCards);

          await actions.init({ commit, rootState }, payload);
          expect(commit).toBeCalledWith(expectedMutation, { paymentCards, defaultCardId });
        });
      });

      describe('addPaymentCard', () => {
        it('should commit ADD_CARD mutation if Parse request has been successful', async () => {
          const commit = jest.fn();
          const expectedMutation = 'ADD_CARD';
          const rootState = {
            user: {
              stripeCustomerToken: 'some fancy token',
            },
          };

          const token = {
            card: 'test',
          };

          Parse.Cloud.run.mockResolvedValue();
          createToken.mockResolvedValue({ token });

          await actions.addPaymentCard({ commit, rootState });
          expect(createToken).toBeCalledWith(rootState.user.stripeCustomerToken);
          expect(commit).toBeCalledWith(expectedMutation, token.card);
        });

        it('should not commit ADD_CARD mutation if Stripe request returned an error', async () => {
          const commit = jest.fn();
          const rootState = {
            user: {
              stripeCustomerToken: 'some fancy token',
            },
          };

          const token = {
            card: 'test',
          };

          const error = {
            message: 'Server error',
          };

          createToken.mockResolvedValue({ token });
          Parse.Cloud.run.mockRejectedValue(error);

          try {
            await actions.addPaymentCard({ commit, rootState });
          } catch (err) {
            expect(createToken).toBeCalledWith(rootState.user.stripeCustomerToken);
            expect(commit).not.toBeCalled();
          }
        });
      });

      describe('removePaymentCard', () => {
        it('should commit DELETE_CARD mutation if card data is valid', async () => {
          const commit = jest.fn();
          const rootState = {
            user: {
              stripeCustomerToken: 'some fancy token',
            },
          };
          const expectedMutation = 'DELETE_CARD';
          const cardId = 'test';

          Parse.Cloud.run.mockResolvedValue();

          await actions.removePaymentCard({ commit, rootState }, cardId);
          jest.runAllTimers();
          expect(commit).toBeCalledWith(expectedMutation, cardId);
        });
      });

      describe('setDefault', () => {
        it('should commit SORT_CARDS_BY_DEFAULT and SET_DEFAULT_CARD_ID mutations if Parse request has been successful', async () => {
          const commit = jest.fn();
          const rootState = {
            user: {
              stripeCustomerToken: 'some fancy token',
            },
          };
          const expectedSetCardDefaultMutation = 'SORT_CARDS_BY_DEFAULT';
          const expectedSetDefaultCardIdMutation = 'SET_DEFAULT_CARD_ID';
          const cardId = 'fancy_id';

          Parse.Cloud.run.mockResolvedValue();

          await actions.setDefault({ commit, rootState }, cardId);
          expect(commit).toBeCalledWith(expectedSetCardDefaultMutation, cardId);
          expect(commit).toBeCalledWith(expectedSetDefaultCardIdMutation, cardId);
        });

        it('should not commit expected mutations if Parse request has been rejected', async () => {
          const commit = jest.fn();
          const rootState = {
            user: {
              stripeCustomerToken: 'some fancy token',
            },
          };
          const cardId = 'test';
          const error = 'error';

          Parse.Cloud.run.mockRejectedValue(error);

          try {
            await actions.removePaymentCard({ commit, rootState }, cardId);
          } catch (e) {
            expect(commit).not.toBeCalled();
          }
        });
      });
    });
  });
});
