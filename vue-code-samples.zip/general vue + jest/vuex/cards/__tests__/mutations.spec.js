import * as mutations from '../mutations';

describe('mutations', () => {
  let state;

  beforeEach(() => {
    state = {};
  });

  describe('INIT', () => {
    test('should add array of cards to state', () => {
      const paymentCards = [
        {
          brand: 'test',
          last4: '1111',
        },
        {
          brand: 'test',
          last4: '1111',
        },
        {
          brand: 'test',
          last4: '1111',
        },
      ];
      const expectedState = {
        paymentCards: [
          {
            brand: 'test',
            last4: '1111',
          },
          {
            brand: 'test',
            last4: '1111',
          },
          {
            brand: 'test',
            last4: '1111',
          },
        ],
      };

      mutations.INIT(state, { paymentCards });
      expect(state).toEqual(expectedState);
    });
  });

  describe('ADD_CARD', () => {
    test('should add one card to state', () => {
      const newCard = {
        brand: 'test',
        last4: '1111',
      };

      state.paymentCards = [];

      const expectedState = {
        paymentCards: [
          {
            brand: 'test',
            last4: '1111',
          },
        ],
      };

      mutations.ADD_CARD(state, newCard);
      expect(state).toEqual(expectedState);
    });
  });

  describe('DELETE_CARD', () => {
    test('should delete one card by cardId from state', () => {
      const cardToDelete = {
        cardId: '1',
      };
      const initialstate = {
        paymentCards: [
          {
            id: '1',
          },
          {
            id: '2',
          },
        ],
      };
      const expectedState = {
        paymentCards: [
          {
            id: '2',
          },
        ],
      };

      mutations.DELETE_CARD(initialstate, cardToDelete.cardId);
      expect(initialstate).toEqual(expectedState);
    });
  });

  describe('SET_DEFAULT_CARD_ID', () => {
    test('should perform expected state modification', () => {
      const defaultCardId = 'card_id';

      state = {
        defaultCardId: '',
      };
      const expectedState = {
        defaultCardId,
      };

      mutations.SET_DEFAULT_CARD_ID(state, defaultCardId);
      expect(state).toEqual(expectedState);
    });
  });

  describe('SORT_CARDS_BY_DEFAULT', () => {
    test('should perform expected state modification', () => {
      const cards = [
        {
          id: '1',
        },
        {
          id: '2',
        },
        {
          id: '3',
        },
      ];

      const expectedCards = [
        {
          id: '3',
        },
        {
          id: '1',
        },
        {
          id: '2',
        },
      ];

      state = {
        paymentCards: cards,
      };

      const expectedState = {
        paymentCards: expectedCards,
      };

      mutations.SORT_CARDS_BY_DEFAULT(state, '3');
      expect(state).toEqual(expectedState);
    });
  });
});
